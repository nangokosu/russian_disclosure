import scrapy
from scrapy_selenium import SeleniumRequest
import pandas as pd


class ScrapeGarageAreaSpider(scrapy.Spider):
    name = 'scraper_commercial_garage'
    allowed_domains = ['www.avito.ru']

    def start_requests(self):
        df = pd.read_csv("all_commercial.csv")
        #df = pd.read_csv("all_garage.csv")
        """
        File --> output csv
        all_commercial.csv --> results_commercial.csv
        all_garage.csv --> results_garage.csv
        """
        url_list = list(df.url)
        for url_item in url_list:
            yield SeleniumRequest(url=url_item, callback=self.parse, meta={"url": url_item})

    def parse(self, response):
        yield {'url': response.request.meta['url'],
               "value": response.xpath("//li[@class='item-params-list-item']//text()").getall()}
